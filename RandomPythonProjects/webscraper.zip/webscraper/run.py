import os

os.system("python3 webscraper.py")
os.system("python3 fileCleanup.py")